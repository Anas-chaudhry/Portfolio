
export interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  tech: string[];
  features: string[];
  image: string;
}

export interface Skill {
  name: string;
  percentage: number;
}

export interface Tool {
  name: string;
  icon: string;
}

export type Theme = 'dark' | 'light';
