
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Theme } from './types';
import { PROJECTS } from './constants';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { ProjectCard } from './components/ProjectCard';
import { Expertise } from './components/Expertise';
import { Contact } from './components/Contact';
import { SplashScreen } from './components/SplashScreen';
import { Sidebar } from './components/Sidebar';
import { Github, Linkedin, Twitter, Instagram } from 'lucide-react';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('annas-theme');
    return (saved as Theme) || 'dark';
  });
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    localStorage.setItem('annas-theme', theme);
    const isDark = theme === 'dark';
    document.body.classList.toggle('bg-slate-950', isDark);
    document.body.classList.toggle('text-white', isDark);
    document.body.classList.toggle('bg-white', !isDark);
    document.body.classList.toggle('text-slate-900', !isDark);
  }, [theme]);

  useEffect(() => {
    if (isSidebarOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isSidebarOpen]);

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'about', 'projects', 'expertise', 'contact'];
      const current = sections.find(section => {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          return rect.top <= 400 && rect.bottom >= 400;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const offset = 140;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  return (
    <>
      <style>{`
        html, body {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        ::-webkit-scrollbar {
          display: none;
        }
        body {
          overflow-x: hidden;
        }
        .text-gradient {
          background: linear-gradient(to right, #6366f1, #a855f7, #ec4899);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
      `}</style>

      <AnimatePresence mode="wait">
        {isLoading && (
          <SplashScreen key="splash" theme={theme} finishLoading={() => setIsLoading(false)} />
        )}
      </AnimatePresence>

      <div className={`transition-colors duration-500 selection:bg-indigo-500 selection:text-white ${theme === 'light' ? 'bg-white' : 'bg-slate-950'}`}>
        
        {!isLoading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }}>
            <Sidebar 
              theme={theme} 
              toggleTheme={toggleTheme} 
              activeSection={activeSection} 
              setActiveSection={setActiveSection}
              isOpen={isSidebarOpen}
              setIsOpen={setIsSidebarOpen}
            />
            
            <Navigation 
              theme={theme} 
              toggleTheme={toggleTheme} 
              activeSection={activeSection} 
              setActiveSection={setActiveSection} 
              onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
              isSidebarOpen={isSidebarOpen}
            />

            <main className="w-full">
              <Hero theme={theme} />

              <section id="about" className="py-24 md:py-32 px-6 relative">
                <div className="max-w-7xl mx-auto text-center relative z-10">
                  <motion.h2 initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-indigo-500 font-bold tracking-widest uppercase text-[10px] md:text-xs mb-8">
                    The Agency Narrative
                  </motion.h2>
                  <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className={`text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black leading-[0.9] tracking-tighter mb-16 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                    We engineer <span className="text-gradient">unfair advantages</span> for visionary clients.
                  </motion.p>
                  <div className="grid md:grid-cols-3 gap-6 md:gap-8 text-left mt-16 md:mt-24">
                    {[
                      { title: 'Innovation First', desc: 'Cutting-edge architectures that scale without limits.' },
                      { title: 'User-Centric', desc: 'Experiences designed to convert and delight every time.' },
                      { title: 'Agile Scale', desc: 'Rapid deployment with enterprise-grade stability.' }
                    ].map((item, i) => (
                      <motion.div key={item.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className={`p-8 md:p-10 rounded-[2.5rem] md:rounded-[3rem] border transition-all duration-500 ${theme === 'light' ? 'bg-white border-slate-200 shadow-xl' : 'bg-white/5 border-white/10'} hover:border-indigo-500/50 group`}>
                        <h3 className={`text-2xl md:text-3xl font-black mb-4 transition-colors ${theme === 'light' ? 'text-slate-900 group-hover:text-indigo-600' : 'text-white group-hover:text-indigo-500'}`}>{item.title}</h3>
                        <p className={`text-base md:text-lg font-inter leading-relaxed ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>{item.desc}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </section>

              <section id="projects" className="py-24 md:py-32 px-6 relative">
                <div className="max-w-7xl mx-auto relative z-10">
                  <div className="flex flex-col md:flex-row justify-between items-end mb-16 md:mb-24 gap-6">
                    <div className="max-w-3xl">
                      <span className="text-indigo-500 font-bold uppercase tracking-widest text-[10px] md:text-xs">Selected Works</span>
                      <h2 className={`text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-tighter mt-4 leading-none ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Case Studies</h2>
                    </div>
                    <motion.button 
                      onClick={() => scrollTo('projects')}
                      whileHover={{ scale: 1.05 }} 
                      whileTap={{ scale: 0.95 }} 
                      className={`hidden md:flex items-center gap-3 px-10 py-5 rounded-2xl border font-black text-lg transition-all shadow-xl ${theme === 'light' ? 'border-indigo-500/30 bg-white text-indigo-600 hover:bg-indigo-500 hover:text-white shadow-indigo-500/5' : 'border-indigo-500/30 text-white hover:bg-indigo-500 hover:text-white shadow-indigo-500/10'}`}
                    >
                      View All
                    </motion.button>
                  </div>
                  <div className="grid md:grid-cols-2 gap-8 lg:gap-16 xl:gap-24">
                    {PROJECTS.map((project) => (
                      <ProjectCard key={project.id} project={project} theme={theme} />
                    ))}
                  </div>
                </div>
              </section>

              <Expertise theme={theme} />
              <Contact theme={theme} />

              <footer className={`pt-20 md:pt-32 pb-8 px-6 border-t ${theme === 'light' ? 'border-slate-200 bg-white' : 'border-white/5 bg-slate-950'}`}>
                <div className="max-w-7xl mx-auto">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-16 mb-20">
                    <div className="lg:col-span-2">
                      <h2 className={`text-4xl md:text-6xl font-black tracking-tighter mb-6 md:mb-8 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                        Annas<span className="text-indigo-500 ml-1">Ch</span>
                      </h2>
                      <p className={`font-inter text-lg md:text-xl leading-relaxed max-w-md ${theme === 'light' ? 'text-slate-700' : 'text-slate-400'}`}>
                        Architecting premium digital experiences for tomorrow's market leaders. PK based, Global Delivery.
                      </p>
                      <div className="flex gap-4 mt-8">
                        {[Twitter, Linkedin, Github, Instagram].map((Icon, i) => (
                          <motion.a key={i} href="#" whileHover={{ y: -5, scale: 1.1 }} className={`w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center border transition-all ${theme === 'light' ? 'bg-white border-slate-200 hover:text-indigo-600' : 'bg-white/5 border-white/10 hover:bg-indigo-600 hover:text-white'}`}>
                            <Icon size={18} md:size={20} />
                          </motion.a>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className={`text-[9px] md:text-[10px] font-black uppercase tracking-[0.3em] mb-6 md:mb-8 ${theme === 'light' ? 'text-slate-400' : 'text-slate-500'}`}>Sitemap</h4>
                      <ul className="space-y-3 md:space-y-4">
                        {['Hero', 'About', 'Projects', 'Expertise', 'Contact'].map((item) => (
                          <li key={item}>
                            <button onClick={() => scrollTo(item.toLowerCase())} className={`font-black text-base md:text-lg transition-colors hover:text-indigo-500 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                              {item}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className={`text-[9px] md:text-[10px] font-black uppercase tracking-[0.3em] mb-6 md:mb-8 ${theme === 'light' ? 'text-slate-400' : 'text-slate-500'}`}>Expertise</h4>
                      <ul className="space-y-3 md:space-y-4">
                        {['Web Apps', 'Mobile', 'UI/UX', 'Cloud'].map((item) => (
                          <li key={item}>
                            <span className={`font-black text-base md:text-lg ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                              {item}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  
                  <div className={`pt-10 border-t flex flex-col md:flex-row items-center justify-between gap-4 ${theme === 'light' ? 'border-slate-200' : 'border-white/5'}`}>
                    <p className={`text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] opacity-40 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      © 2025 Annas Ch.
                    </p>
                    <p className={`text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] flex items-center gap-2 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      Made with <span className="text-rose-500 animate-pulse text-sm md:text-lg">♥️</span> PK
                    </p>
                    <p className={`text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] opacity-40 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      Privacy Policy / Terms
                    </p>
                  </div>
                </div>
              </footer>
            </main>
          </motion.div>
        )}
      </div>
    </>
  );
};

export default App;
