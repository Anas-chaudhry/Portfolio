
import { Project, Skill, Tool } from './types';

export const PROJECTS: Project[] = [
  {
    id: 'ecommerce',
    title: 'E-Commerce Platform',
    category: 'Web Development',
    description: 'Full-featured e-commerce system with secure authentication, admin dashboard, and payment integration.',
    tech: ['React', 'Node.js', 'MongoDB', 'Stripe', 'REST API', 'JWT Auth'],
    features: ['Secure Auth', 'Admin Dashboard', 'Responsive UI'],
    image: 'https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'fitness',
    title: 'Fitness Tracking App',
    category: 'App Development',
    description: 'Cross-platform mobile app with real-time health data, analytics, and cloud sync.',
    tech: ['React Native', 'Firebase', 'API Integration', 'State Management'],
    features: ['Real-time Data', 'Push Notifications', 'Charts', 'Authentication'],
    image: 'https://images.unsplash.com/photo-1510017803434-a899398421b3?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'branding',
    title: 'Brand Identity Design',
    category: 'Graphic Design',
    description: 'Complete branding system with visual identity, typography, and social media assets for elite agencies.',
    tech: ['Branding', 'Visual Identity', 'Typography', 'Color System'],
    features: ['Brand Guidelines', 'Social Media Kit', 'UI Assets'],
    image: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dashboard',
    title: 'Admin Dashboard',
    category: 'Web Application',
    description: 'Role-based admin panel with analytics, charts, and full CRUD management.',
    tech: ['Next.js', 'SaaS', 'Admin Panel', 'REST API', 'Secure Auth'],
    features: ['Dashboard', 'Charts', 'Role Based Access', 'CRUD', 'Analytics'],
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80'
  }
];

export const SKILLS: Skill[] = [
  { name: 'React / Next.js', percentage: 95 },
  { name: 'TypeScript', percentage: 90 },
  { name: 'Node.js', percentage: 92 },
  { name: 'React Native', percentage: 100 },
  { name: 'UI/UX Design', percentage: 100 },
  { name: 'Figma / Adobe XD', percentage: 90 },
  { name: 'Adobe Creative Suite', percentage: 88 },
  { name: 'Tailwind CSS', percentage: 95 },
  { name: 'CSS', percentage: 100 },
  { name: 'Html', percentage: 100 },
  { name: 'Javascript', percentage: 100 }
];

export const TOOLS: Tool[] = [
  { name: 'Figma', icon: 'figma' },
  { name: 'VS Code', icon: 'vscode' },
  { name: 'Android', icon: 'android' },
  { name: 'Apple', icon: 'apple' },
  { name: 'Github', icon: 'github' },
  { name: 'Docker', icon: 'docker' },
  { name: 'Cloud', icon: 'cloud' },
  { name: 'Vercel', icon: 'vercel' },
  { name: 'Design', icon: 'design' },
  { name: 'Sparkles', icon: 'sparkles' },
  { name: 'Video', icon: 'video' },
  { name: 'Creative', icon: 'creative' },
  { name: 'Motion', icon: 'motion' },
  { name: 'Media', icon: 'media' },
  { name: 'Workspace', icon: 'workspace' },
  { name: 'Connect', icon: 'connect' }
];
