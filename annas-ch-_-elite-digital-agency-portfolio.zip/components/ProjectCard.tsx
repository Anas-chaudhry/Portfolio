
import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, ArrowRight, Code2 } from 'lucide-react';
import { Project, Theme } from '../types';

interface ProjectCardProps {
  project: Project;
  theme: Theme;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, theme }) => {
  return (
    <motion.div
      whileHover={{ y: -10 }}
      className={`group relative rounded-[2.5rem] md:rounded-[3rem] overflow-hidden border transition-all duration-700 flex flex-col h-full ${
        theme === 'light' ? 'bg-white border-slate-200 shadow-xl shadow-slate-200/50' : 'bg-slate-900 border-white/5 shadow-2xl shadow-black/20'
      }`}
    >
      {/* Image Section */}
      <div className="aspect-[16/10] overflow-hidden relative">
        <img 
          src={project.image} 
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 group-hover:rotate-1"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-6 md:p-8">
           <div className="flex gap-2 md:gap-4">
             {project.features.slice(0, 2).map(f => (
               <span key={f} className="px-3 py-1.5 md:px-4 md:py-2 rounded-full glass text-[9px] md:text-xs font-bold text-white backdrop-blur-md border border-white/20">
                 {f}
               </span>
             ))}
           </div>
        </div>
        
        {/* Floating Category Tag */}
        <div className="absolute top-4 left-4 md:top-6 md:left-6 px-3 py-1.5 md:px-4 md:py-2 rounded-full glass border border-white/20 backdrop-blur-xl shadow-xl">
           <span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] text-white">
             {project.category}
           </span>
        </div>
      </div>

      {/* Content Section */}
      <div className="p-8 md:p-10 flex flex-col flex-1">
        <h3 className={`text-2xl sm:text-3xl md:text-4xl font-black mb-3 md:mb-4 tracking-tighter ${theme === 'light' ? 'text-slate-900' : 'text-white'} group-hover:text-indigo-500 transition-colors`}>
          {project.title}
        </h3>

        <p className={`text-sm md:text-base mb-6 md:mb-8 font-inter leading-relaxed line-clamp-3 ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
          {project.description}
        </p>

        {/* Tech Stack Pills */}
        <div className="flex flex-wrap gap-2 mb-8 md:mb-10 mt-auto">
          {project.tech.map((t) => (
            <span key={t} className={`text-[9px] md:text-[10px] font-black px-2.5 py-1.5 md:px-3 md:py-1.5 rounded-lg uppercase tracking-widest flex items-center gap-1.5 ${
              theme === 'light' ? 'bg-slate-100 text-slate-700' : 'bg-white/5 text-slate-300 border border-white/5'
            }`}>
              <div className="w-1 h-1 rounded-full bg-indigo-500" />
              {t}
            </span>
          ))}
        </div>

        {/* Action Button */}
        <button className={`w-full py-4 md:py-5 rounded-2xl flex items-center justify-center gap-3 font-black text-base md:text-lg transition-all shadow-lg ${
          theme === 'light' 
            ? 'bg-slate-950 text-white hover:bg-indigo-600 shadow-slate-950/20' 
            : 'bg-white text-slate-950 hover:bg-indigo-500 hover:text-white shadow-white/5'
        }`}>
          Case Study <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </motion.div>
  );
};
