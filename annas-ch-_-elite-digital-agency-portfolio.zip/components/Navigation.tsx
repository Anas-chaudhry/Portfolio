
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { LayoutGrid, User, FolderOpen, Zap, MessageSquare, Moon, Sun, Menu, X } from 'lucide-react';
import { Theme } from '../types';

interface NavigationProps { 
  theme: Theme; 
  toggleTheme: () => void; 
  activeSection: string; 
  setActiveSection: (section: string) => void; 
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
}

const navItems = [
  { id: 'hero', icon: LayoutGrid, label: 'Home' },
  { id: 'about', icon: User, label: 'About' },
  { id: 'projects', icon: FolderOpen, label: 'Work' },
  { id: 'expertise', icon: Zap, label: 'Skills' },
  { id: 'contact', icon: MessageSquare, label: 'Contact' },
];

export const Navigation: React.FC<NavigationProps> = ({ theme, toggleTheme, activeSection, setActiveSection, onToggleSidebar, isSidebarOpen }) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    setActiveSection(id);
    const el = document.getElementById(id);
    if (el) {
      const offset = 140; 
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  return (
    <div className="fixed top-0 left-0 right-0 z-[200] px-6 md:px-12 py-4 md:py-6 flex justify-center pointer-events-none">
      <motion.nav 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        style={{ backdropFilter: 'blur(19px)' }}
        className={`w-full max-w-6xl grid grid-cols-[auto_1fr_auto] items-center px-6 md:px-10 py-[20px] md:py-[25px] rounded-3xl md:rounded-[2.5rem] pointer-events-auto transition-all duration-700 border shadow-[0_20px_50px_-12px_rgba(0,0,0,0.2)] ${
          theme === 'light' 
            ? 'bg-white/85 border-slate-300 shadow-lg shadow-slate-200/50' 
            : 'bg-slate-900/80 border-white/25 shadow-2xl shadow-black/80'
        } ${isScrolled ? 'scale-[0.98] py-[14px] md:py-[18px] px-6' : 'scale-100'}`}
      >
        {/* Logo Section (Left) */}
        <div 
          className="flex items-center gap-3 md:gap-5 cursor-pointer group" 
          onClick={() => scrollTo('hero')}
        >
          <div 
            className="w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center shadow-xl shadow-indigo-500/30 overflow-hidden relative"
            style={{ perspective: '1000px' }}
          >
            <motion.span 
              animate={{ rotateY: 360 }}
              transition={{ duration: 3.5, repeat: Infinity, ease: "linear" }}
              className="text-white font-black text-lg md:text-2xl inline-block"
            >
              A
            </motion.span>
          </div>
          <div className="flex flex-col">
            <span className={`font-black text-lg sm:text-xl md:text-3xl lg:text-4xl tracking-tighter leading-none ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
              Annas<span className="text-indigo-500 ml-1">Ch</span>
            </span>
            <span className="text-[6px] md:text-[8px] font-black tracking-[0.4em] uppercase opacity-40 mt-1 block">Creative dev</span>
          </div>
        </div>

        {/* Center Navigation Menu */}
        <div className="flex justify-center px-4">
          <div className={`hidden md:flex items-center gap-1.5 p-1 rounded-full ${theme === 'light' ? 'bg-slate-100/50' : 'bg-white/5'}`}>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className={`relative px-4 lg:px-6 py-2 rounded-full transition-all flex flex-col items-center gap-0.5 min-w-[70px] lg:min-w-[90px] ${
                  activeSection === item.id 
                    ? 'text-indigo-600 bg-white shadow-lg' 
                    : theme === 'light' ? 'text-slate-500 hover:text-slate-900' : 'text-slate-400 hover:text-white'
                }`}
              >
                <item.icon size={16} className={activeSection === item.id ? 'text-indigo-500' : 'opacity-60'} />
                <span className={`text-[8px] lg:text-[9px] font-black uppercase tracking-widest`}>{item.label}</span>
                {activeSection === item.id && (
                  <motion.div 
                    layoutId="active-nav-indicator" 
                    className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-indigo-500 rounded-full" 
                  />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Action Controls (Right) */}
        <div className="flex items-center gap-3 md:gap-5">
          <button
            onClick={toggleTheme}
            className={`w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center transition-all ${
              theme === 'light' ? 'bg-slate-100 text-slate-800' : 'bg-white/10 text-slate-300'
            } border ${theme === 'light' ? 'border-slate-200' : 'border-transparent'} hover:scale-105 active:scale-95`}
          >
            {theme === 'light' ? <Moon size={20} md:size={24} /> : <Sun size={20} md:size={24} />}
          </button>
          
          <button 
            onClick={onToggleSidebar}
            className={`md:hidden w-10 h-10 rounded-xl text-white flex items-center justify-center transition-all bg-indigo-600 shadow-lg`}
          >
            {isSidebarOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </motion.nav>
    </div>
  );
};
