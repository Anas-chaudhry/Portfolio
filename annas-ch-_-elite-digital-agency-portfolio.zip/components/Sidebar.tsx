
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutGrid, User, FolderOpen, Zap, MessageSquare } from 'lucide-react';
import { Theme } from '../types';

interface SidebarProps {
  theme: Theme;
  toggleTheme: () => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const navItems = [
  { id: 'hero', icon: LayoutGrid, label: 'Home' },
  { id: 'about', icon: User, label: 'About' },
  { id: 'projects', icon: FolderOpen, label: 'Work' },
  { id: 'expertise', icon: Zap, label: 'Skills' },
  { id: 'contact', icon: MessageSquare, label: 'Contact' },
];

export const Sidebar: React.FC<SidebarProps> = ({ theme, activeSection, setActiveSection, isOpen, setIsOpen }) => {
  const scrollTo = (id: string) => {
    setActiveSection(id);
    setIsOpen(false);
    const el = document.getElementById(id);
    if (el) {
      const offset = 140;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Enhanced Glassy Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className={`fixed inset-0 z-[180] backdrop-blur-[30px] backdrop-saturate-150 transition-colors duration-500 ${
              theme === 'light' ? 'bg-white/40' : 'bg-slate-950/40'
            }`}
          />

          {/* Premium Glass Overlay Menu */}
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -40, scale: 0.98 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className={`fixed top-32 md:top-44 left-4 right-4 md:left-1/2 md:-translate-x-1/2 md:w-[500px] z-[190] p-6 md:p-8 rounded-[3rem] border shadow-[0_50px_100px_-20px_rgba(0,0,0,0.15)] overflow-hidden ${
              theme === 'light' 
                ? 'bg-white/70 border-slate-300 backdrop-blur-3xl backdrop-saturate-150 shadow-slate-200/50' 
                : 'bg-slate-900/85 border-white/25 backdrop-blur-3xl shadow-black/90'
            }`}
          >
            {/* Animated Background Decor */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-[80px] -mr-24 -mt-24" />
            
            <div className="relative z-10 flex flex-col gap-4">
              <div className="grid grid-cols-1 gap-3">
                {navItems.map((item, i) => (
                  <motion.button
                    key={item.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    onClick={() => scrollTo(item.id)}
                    className={`flex items-center gap-5 p-5 rounded-[2rem] transition-all font-black text-xl group ${
                      activeSection === item.id 
                        ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/30' 
                        : theme === 'light' ? 'text-slate-700 hover:bg-slate-200/50 border border-transparent hover:border-slate-300' : 'text-slate-300 hover:bg-white/5 border border-transparent hover:border-white/10'
                    }`}
                  >
                    <item.icon size={24} className={`transition-transform duration-500 ${activeSection === item.id ? 'scale-110' : 'group-hover:scale-110'}`} />
                    <span>{item.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
