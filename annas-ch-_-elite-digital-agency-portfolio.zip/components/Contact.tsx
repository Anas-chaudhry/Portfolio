
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MessageCircle, Send, ArrowUpRight } from 'lucide-react';
import { Theme } from '../types';

interface ContactProps {
  theme: Theme;
}

export const Contact: React.FC<ContactProps> = ({ theme }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectType: '',
    message: ''
  });
  const [error, setError] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (error) setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      setError('Please fill in all required fields.');
      return;
    }

    const subject = `New Project Inquiry: ${formData.projectType || 'General Inquiry'} from ${formData.name}`;
    const body = `Name: ${formData.name}\nEmail: ${formData.email}\nProject Interest: ${formData.projectType}\n\nMessage:\n${formData.message}`;
    
    const mailtoUrl = `mailto:annaschawdhary157@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    
    window.location.href = mailtoUrl;
  };

  return (
    <section id="contact" className="py-20 md:py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          <div className="lg:w-1/2">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black mb-6 md:mb-8 leading-none ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}
            >
              Ready to <br />
              <span className="text-indigo-500">Scale Up?</span>
            </motion.h2>
            <p className={`text-lg md:text-xl font-inter mb-10 md:mb-12 max-w-md ${theme === 'light' ? 'text-slate-700' : 'text-slate-400'}`}>
              Let's craft your next digital masterpiece. From strategy to deployment, we are your elite engineering partner.
            </p>

            <div className="space-y-5 md:space-y-6">
              <a href="mailto:annaschawdhary157@gmail.com" className="flex items-center gap-4 group">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-indigo-600/10 flex items-center justify-center text-indigo-500 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                  <Mail size={20} md:size={24} />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest block">Email Us</span>
                  <span className={`text-base md:text-lg font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>annaschawdhary157@gmail.com</span>
                </div>
              </a>
              <a href="tel:+923421000932" className="flex items-center gap-4 group">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-purple-600/10 flex items-center justify-center text-purple-500 group-hover:bg-purple-600 group-hover:text-white transition-all">
                  <Phone size={20} md:size={24} />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-purple-500 uppercase tracking-widest block">Direct Line</span>
                  <span className={`text-base md:text-lg font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>+92 342 1000932</span>
                </div>
              </a>
              <a href="https://wa.me/923421000932" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-emerald-600/10 flex items-center justify-center text-emerald-500 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                  <MessageCircle size={20} md:size={24} />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest block">WhatsApp</span>
                  <span className={`text-base md:text-lg font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Message our team</span>
                </div>
              </a>
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className={`lg:w-1/2 p-6 md:p-12 rounded-[2.5rem] md:rounded-[3rem] border ${
              theme === 'light' ? 'bg-white border-slate-300 shadow-xl' : 'bg-slate-900 border-white/10'
            }`}
          >
            <form className="space-y-5 md:space-y-6" onSubmit={handleSubmit}>
              <div className="grid md:grid-cols-2 gap-5 md:gap-6">
                <div className="space-y-2">
                  <label className={`text-[10px] md:text-xs font-bold uppercase tracking-widest ml-1 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Full Name</label>
                  <input 
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    type="text" 
                    placeholder="John Doe"
                    required
                    className={`w-full px-5 py-3.5 md:px-6 md:py-4 rounded-xl md:rounded-2xl outline-none border transition-all text-sm md:text-base ${
                      theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-indigo-500 text-slate-900' : 'bg-white/5 border-white/10 focus:border-indigo-500 text-white'
                    }`}
                  />
                </div>
                <div className="space-y-2">
                  <label className={`text-[10px] md:text-xs font-bold uppercase tracking-widest ml-1 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Email Address</label>
                  <input 
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    type="email" 
                    placeholder="john@company.com"
                    required
                    className={`w-full px-5 py-3.5 md:px-6 md:py-4 rounded-xl md:rounded-2xl outline-none border transition-all text-sm md:text-base ${
                      theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-indigo-500 text-slate-900' : 'bg-white/5 border-white/10 focus:border-indigo-500 text-white'
                    }`}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className={`text-[10px] md:text-xs font-bold uppercase tracking-widest ml-1 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Project Interest</label>
                <input 
                  name="projectType"
                  value={formData.projectType}
                  onChange={handleInputChange}
                  type="text"
                  placeholder="e.g. Mobile App, E-commerce..."
                  className={`w-full px-5 py-3.5 md:px-6 md:py-4 rounded-xl md:rounded-2xl outline-none border transition-all text-sm md:text-base ${
                    theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-indigo-500 text-slate-900' : 'bg-white/5 border-white/10 focus:border-indigo-500 text-white'
                  }`}
                />
              </div>
              <div className="space-y-2">
                <label className={`text-[10px] md:text-xs font-bold uppercase tracking-widest ml-1 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Message</label>
                <textarea 
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={4}
                  placeholder="Tell us about your project goals..."
                  required
                  className={`w-full px-5 py-3.5 md:px-6 md:py-4 rounded-xl md:rounded-2xl outline-none border transition-all resize-none text-sm md:text-base ${
                    theme === 'light' ? 'bg-slate-50 border-slate-200 focus:border-indigo-500 text-slate-900' : 'bg-white/5 border-white/10 focus:border-indigo-500 text-white'
                  }`}
                ></textarea>
              </div>

              {error && (
                <p className="text-rose-500 text-[10px] md:text-sm font-bold ml-1">{error}</p>
              )}

              <button 
                type="submit"
                className="w-full py-4 md:py-5 rounded-xl md:rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black text-base md:text-lg flex items-center justify-center gap-3 hover:scale-[1.01] active:scale-95 shadow-xl transition-all"
              >
                Send Message <Send size={18} />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
