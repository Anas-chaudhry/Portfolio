
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { Theme } from '../types';

interface SplashScreenProps {
  finishLoading: () => void;
  theme: Theme;
}

const BOOT_LOGS = [
  "Initializing Kernel...",
  "Loading UI Framework v4.2.0...",
  "Calibrating Motion Engines...",
  "Establishing Secure Handshake...",
  "Mapping Digital Topography...",
  "Compiling Asset Bundles...",
  "Optimizing Visual Shaders...",
  "Synchronizing Agency Protocols...",
  "System Ready. Interface Online."
];

export const SplashScreen: React.FC<SplashScreenProps> = ({ finishLoading, theme }) => {
  const [progress, setProgress] = useState(0);
  const [logIndex, setLogIndex] = useState(0);
  const name = "Annas Ch";
  const isDark = theme === 'dark';

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + (Math.random() * 3);
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(finishLoading, 600);
          return 100;
        }
        return next;
      });
    }, 30);

    const logTimer = setInterval(() => {
      setLogIndex(prev => (prev < BOOT_LOGS.length - 1 ? prev + 1 : prev));
    }, 350);

    return () => {
      clearInterval(timer);
      clearInterval(logTimer);
    };
  }, [finishLoading]);

  const charVariants: Variants = {
    hidden: { opacity: 0, scale: 0.9, y: 10, filter: "blur(10px)" },
    visible: (i: number) => ({
      opacity: 1,
      scale: 1,
      y: 0,
      filter: "blur(0px)",
      transition: {
        delay: 0.05 * i,
        duration: 0.4,
        ease: [0.2, 0.65, 0.3, 0.9] as [number, number, number, number],
      },
    }),
  };

  return (
    <motion.div
      exit={{ opacity: 0, scale: 1.05, filter: "blur(30px)" }}
      transition={{ duration: 0.6 }}
      className={`fixed inset-0 z-[1000] flex flex-col items-center justify-center overflow-hidden font-inter transition-colors duration-500 ${
        isDark ? 'bg-slate-950 text-white' : 'bg-slate-50 text-slate-900'
      }`}
    >
      <div className={`absolute inset-0 opacity-[0.03] pointer-events-none ${isDark ? 'invert-0' : 'invert'}`} 
           style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      <motion.div 
        animate={{ top: ['0%', '100%'] }}
        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        className={`absolute left-0 right-0 h-[1px] z-0 ${
          isDark ? 'bg-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.5)]' : 'bg-indigo-600/10'
        }`}
      />

      <div className="relative flex flex-col items-center max-w-2xl w-full px-8 text-center z-10">
        <div className={`flex items-center justify-between w-full mb-12 opacity-40 font-mono text-[8px] md:text-[10px] tracking-widest uppercase ${isDark ? 'text-white' : 'text-slate-900'}`}>
          <div className="flex items-center gap-2">
            <div className={`w-1 h-1 rounded-full animate-pulse ${isDark ? 'bg-emerald-500' : 'bg-emerald-600'}`} />
            <span>CONNECTION: OK</span>
          </div>
          <span>PK_NODE_01</span>
        </div>

        <div className="relative mb-10">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-center gap-1 md:gap-2 mb-2"
          >
            {name.split("").map((char, i) => (
              <motion.span
                key={i}
                custom={i}
                variants={charVariants}
                initial="hidden"
                animate="visible"
                className={`text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-tighter ${
                  char === 'C' || char === 'h' ? 'text-indigo-500' : (isDark ? 'text-white' : 'text-slate-900')
                }`}
              >
                {char === " " ? "\u00A0" : char}
              </motion.span>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          transition={{ delay: 1 }}
          className="flex items-center gap-4 mb-16"
        >
          <div className={`h-px w-6 ${isDark ? 'bg-indigo-500/30' : 'bg-indigo-600/20'}`} />
          <p className={`${isDark ? 'text-indigo-400' : 'text-indigo-700'} text-[8px] md:text-[10px] font-black uppercase tracking-[0.8em] whitespace-nowrap`}>
            Elite Creative Technologist
          </p>
          <div className={`h-px w-6 ${isDark ? 'bg-indigo-500/30' : 'bg-indigo-600/20'}`} />
        </motion.div>

        <div className="w-full max-w-[300px] h-5 mb-8 overflow-hidden text-center">
           <AnimatePresence mode="wait">
             <motion.p
               key={logIndex}
               initial={{ y: 15, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               exit={{ y: -15, opacity: 0 }}
               className={`text-[8px] md:text-[9px] font-mono uppercase tracking-widest ${isDark ? 'text-indigo-300/50' : 'text-indigo-900/30'}`}
             >
               {BOOT_LOGS[logIndex]}
             </motion.p>
           </AnimatePresence>
        </div>

        <div className="w-full max-w-[220px] flex flex-col items-center gap-3">
          <div className={`w-full h-[3px] rounded-full overflow-hidden ${
            isDark ? 'bg-white/5' : 'bg-slate-200'
          }`}>
            <motion.div 
              className="h-full bg-gradient-to-r from-indigo-600 to-purple-500 shadow-[0_0_10px_#6366f1]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className={`flex justify-between w-full font-mono text-[8px] opacity-40 ${isDark ? 'text-white' : 'text-slate-900'}`}>
            <span>DEPLOY_SYNC</span>
            <span className="tabular-nums">{Math.round(progress)}%</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
