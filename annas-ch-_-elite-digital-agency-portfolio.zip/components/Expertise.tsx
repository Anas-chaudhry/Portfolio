
import React from 'react';
import { motion } from 'framer-motion';
import { SKILLS, TOOLS } from '../constants';
import { Theme } from '../types';
import { 
  Figma, 
  Code2, 
  Smartphone, 
  Apple, 
  Github, 
  Database, 
  Cloud, 
  Zap, 
  Palette, 
  Sparkles, 
  Video, 
  Layers, 
  Cpu, 
  Film, 
  Layout, 
  MessagesSquare 
} from 'lucide-react';

interface ExpertiseProps {
  theme: Theme;
}

const getToolIcon = (iconName: string, theme: Theme) => {
  const iconClasses = "transition-all duration-300 size-8 sm:size-9 md:size-10 lg:size-11";
  const iconProps = { strokeWidth: 1.5 };
  
  switch (iconName) {
    case 'figma': return <Figma {...iconProps} className={`${iconClasses} text-[#F24E1E]`} />;
    case 'vscode': return <Code2 {...iconProps} className={`${iconClasses} text-[#007ACC]`} />;
    case 'android': return <Smartphone {...iconProps} className={`${iconClasses} text-[#3DDC84]`} />;
    case 'apple': return <Apple {...iconProps} className={`${iconClasses} ${theme === 'light' ? 'text-slate-900' : 'text-white'}`} />;
    case 'github': return <Github {...iconProps} className={`${iconClasses} ${theme === 'light' ? 'text-slate-900' : 'text-indigo-400'}`} />;
    case 'docker': return <Database {...iconProps} className={`${iconClasses} text-[#2496ED]`} />;
    case 'cloud': return <Cloud {...iconProps} className={`${iconClasses} text-[#00A4EF]`} />;
    case 'vercel': return <Zap {...iconProps} className={`${iconClasses} text-amber-400`} />;
    case 'design': return <Palette {...iconProps} className={`${iconClasses} text-pink-500`} />;
    case 'sparkles': return <Sparkles {...iconProps} className={`${iconClasses} text-indigo-400`} />;
    case 'video': return <Video {...iconProps} className={`${iconClasses} text-rose-500`} />;
    case 'creative': return <Layers {...iconProps} className={`${iconClasses} text-purple-500`} />;
    case 'motion': return <Cpu {...iconProps} className={`${iconClasses} text-emerald-500`} />;
    case 'media': return <Film {...iconProps} className={`${iconClasses} text-orange-500`} />;
    case 'workspace': return <Layout {...iconProps} className={`${iconClasses} text-cyan-500`} />;
    case 'connect': return <MessagesSquare {...iconProps} className={`${iconClasses} text-indigo-600`} />;
    default: return <Code2 {...iconProps} className={iconClasses} />;
  }
};

export const Expertise: React.FC<ExpertiseProps> = ({ theme }) => {
  return (
    <section id="expertise" className="py-20 md:py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-start">
          
          {/* Skills Column */}
          <div>
            <span className="text-indigo-500 font-bold uppercase tracking-widest text-[10px] md:text-xs mb-4 block">Expertise</span>
            <motion.h2 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className={`text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black mb-6 tracking-tighter leading-none ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}
            >
              Skills & <br /><span className="text-gradient">Tools</span>
            </motion.h2>
            <p className={`text-lg md:text-xl font-inter mb-12 md:mb-16 max-w-lg ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
              Constantly learning and improving. Here are the technologies and tools I use to bring ideas to life.
            </p>
            
            <div className="space-y-10">
              <h3 className={`text-xl md:text-2xl font-black mb-8 border-l-4 border-indigo-500 pl-4 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Technical Skills</h3>
              <div className="grid sm:grid-cols-2 gap-x-8 lg:gap-x-12 gap-y-8 lg:gap-y-10">
                {SKILLS.map((skill, index) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-end mb-2.5">
                      <span className={`font-black text-base md:text-lg tracking-tighter ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>{skill.name}</span>
                      <span className="font-inter text-indigo-500 font-black text-xs md:text-sm">{skill.percentage}%</span>
                    </div>
                    <div className={`h-2 w-full rounded-full ${theme === 'light' ? 'bg-slate-100' : 'bg-white/5'} overflow-hidden`}>
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.percentage}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.2, delay: index * 0.05, ease: "circOut" }}
                        className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full relative"
                      >
                        <div className="absolute top-0 right-0 h-full w-8 bg-white/20 blur-sm" />
                      </motion.div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Tools Grid Column */}
          <div className="lg:sticky lg:top-32">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`p-6 sm:p-10 lg:p-14 rounded-[2rem] sm:rounded-[3rem] lg:rounded-[3.5rem] border shadow-2xl ${
                theme === 'light' ? 'bg-white border-slate-200 shadow-xl shadow-slate-200/50' : 'bg-slate-900/40 border-white/5 shadow-black/40'
              }`}
            >
              <h3 className={`text-xl sm:text-2xl lg:text-3xl font-black mb-6 lg:mb-10 tracking-tighter ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Tools Arsenal</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-6">
                {TOOLS.map((tool, index) => (
                  <motion.div
                    key={tool.name}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    whileHover={{ y: -5, scale: 1.02 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.02, type: 'spring', stiffness: 300 }}
                    className={`aspect-square flex flex-col items-center justify-center gap-3 md:gap-4 rounded-2xl md:rounded-[2rem] border transition-all duration-500 ${
                      theme === 'light' 
                        ? 'bg-slate-50 border-slate-200 hover:bg-white hover:shadow-lg' 
                        : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-indigo-500/50'
                    }`}
                  >
                    <div className="relative group/icon flex items-center justify-center">
                      {getToolIcon(tool.icon, theme)}
                    </div>
                    <span className={`text-[10px] sm:text-[11px] md:text-xs font-black uppercase tracking-widest text-center px-2 ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>{tool.name}</span>
                  </motion.div>
                ))}
              </div>

              {/* Founder's Premium Quote Section */}
              <div className="mt-10 lg:mt-16 pt-8 lg:pt-10 border-t border-indigo-500/20">
                <div className="relative">
                  <span className="absolute -top-4 -left-2 text-4xl sm:text-6xl font-serif text-indigo-500/20">"</span>
                  <p className={`text-sm sm:text-lg lg:text-xl font-inter leading-relaxed italic font-light relative z-10 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                    Technology is a brush to paint the future. We select the best tech stacks for performance.
                  </p>
                </div>
                
                <div className="mt-8 flex items-center gap-4">
                  <div className="relative">
                    <div className="w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 p-0.5">
                      <div className="w-full h-full rounded-xl md:rounded-2xl bg-slate-950 flex items-center justify-center font-black text-xs md:text-lg text-white">AC</div>
                    </div>
                  </div>
                  <div>
                    <h4 className={`text-base md:text-xl font-black tracking-tight ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Annas Ch</h4>
                    <p className="text-[8px] md:text-xs font-black uppercase tracking-[0.2em] text-indigo-500">Founder & Lead Technologist</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};
